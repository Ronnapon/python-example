from shopping.Sale3 import calc_tax
from customer.contact import company

company()
calc_tax()


def calc_tax():
    print("Calprice")


def calc_shipping():
    print("Caltax")
