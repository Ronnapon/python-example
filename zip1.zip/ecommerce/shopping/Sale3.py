print("Sale3", __name__)


def calc_tax():
    print("Calprice")


def calc_shipping():
    print("Caltax")


if __name__ == "__main__":
    print("Hello")
    calc_tax()
