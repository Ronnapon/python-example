print("initail Shopping", __name__)
