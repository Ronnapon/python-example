print("Initail Ecommerce", __name__)
